# image-classification-tensorflow-teachable-machine


<p align="center">
<a href="https://www.youtube.com/watch?v=aVKGjzAUHz0">
    <img width="600" src="https://utils-computervisiondeveloper.s3.amazonaws.com/thumbnails/with_play_button/image_classifier_tensorflow_teachable_machine.jpg" alt="Watch the video">
    </br>Watch on YouTube: Image classification with TensorFlow and Teachable Machine !
</a>
</p>
